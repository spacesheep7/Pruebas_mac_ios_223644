//
//  conversacion_hogar.swift
//  Pantallas_ejercicio5
//
//  Created by alumno on 11/9/26.
//

import SwiftUI


struct ControlHogarVista: View {
    @Environment(MensajesControl.self) var mensajeria
    @State private var seleccion = 0
    
    var body: some View {
        TabView(selection: $seleccion){
            Tab("Bienvenida", systemImage: "sparkles", value: 0){
                BienvenidaPantalla(irAlAltar: { seleccion = 1 })
            }
            
            Tab("Hogar", systemImage: "apple.homekit", value: 1){
                ARPantalla()
            }
            
            Tab("Mensajes", systemImage: "message", value: 2){
                ConversacionesControlVista()
            }
            .badge(mensajeria.conversaciones.count)
            
            Tab("Configuracion", systemImage: "gear", value: 3){
                Configuracion()
            }
        }
    }
}


#Preview {
    ControlHogarVista()
        .environment(MensajesControl())
}
