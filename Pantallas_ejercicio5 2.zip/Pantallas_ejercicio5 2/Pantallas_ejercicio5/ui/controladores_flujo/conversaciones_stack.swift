//
//  conversaciones_stack.swift
//  Pantallas_ejercicio5
//
//  Created by alumno on 11/9/26.
//

import SwiftUI

struct ConversacionesControlVista:View {
    @Environment(MensajesControl.self) var mensajes_control
    
    var body: some View {
        NavigationStack
        {
            ScrollView {
                LazyVStack(spacing: 10) {
                    ForEach(mensajes_control.conversaciones){ conversacion in NavigationLink{
                        MensajesPantalla(mensajes: conversacion.mensajes,
                                         yo: conversacion.remitente,
                                         titulo: conversacion.receptor)
                    }
                        label: {
                            ConversacionPrevista(conversacion: conversacion)
                                .padding(14)
                                .foregroundColor(.papelPicado)
                                .background(Color.moradoAltar)
                                .clipShape(RoundedRectangle(cornerRadius: 22))
                        }
                        .buttonStyle(.plain)
                        .padding(.horizontal, 12)
                        
                    }
                }
                .padding(.vertical, 8)
            }
            .background(Color.papelPicado)
            .navigationTitle("Mensajes")
        }
    }
}

#Preview {
    ConversacionesControlVista()
        .environment(MensajesControl())
}
