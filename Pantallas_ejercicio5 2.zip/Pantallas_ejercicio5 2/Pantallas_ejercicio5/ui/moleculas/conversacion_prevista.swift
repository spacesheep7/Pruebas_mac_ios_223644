//
//  conversacion_prevista.swift
//  Pantallas_ejercicio5
//
//  Created by alumno on 11/9/26.
//

import SwiftUI

struct ConversacionPrevista: View{
    let conversacion: Conversacion
    
    var iniciales: String {
        String(conversacion.remitente.prefix(1)) + String(conversacion.receptor.prefix(1))
    }
    
    var ultimoMensaje: Mensaje? {
        conversacion.mensajes.last(where: { $0.remitente != nil })
    }
    
    var body: some View{
        HStack(spacing: 12) {
            Text(iniciales)
                .font(.headline)
                .foregroundColor(.nocheAltar)
                .frame(width: 52, height: 52)
                .background(Circle().fill(Color.cempasuchil))
            
            VStack(alignment: .leading, spacing: 4) {
                Text("\(conversacion.remitente) y \(conversacion.receptor)")
                    .font(.headline)
                    .lineLimit(1)
                
                if let ultimo = ultimoMensaje {
                    Text("\(ultimo.remitente ?? ""): \(ultimo.cuerpo)")
                        .font(.subheadline)
                        .lineLimit(2)
                        .opacity(0.8)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            
            Text("\(conversacion.mensajes.count)")
                .font(.caption.bold())
                .foregroundColor(.nocheAltar)
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(Capsule().fill(Color.cempasuchil))
        }
    }
}

#Preview {
    ConversacionPrevista(conversacion: ConversacionesFalsas[0])
        .padding()
        .background(Color.moradoAltar)
}
