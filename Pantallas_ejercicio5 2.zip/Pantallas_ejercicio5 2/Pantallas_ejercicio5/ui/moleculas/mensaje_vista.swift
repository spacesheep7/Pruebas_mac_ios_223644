//
//  mensaje_vista.swift
//  Pantallas_ejercicio5
//
//  Created by alumno on 11/9/26.
//

import SwiftUI


struct MensajeVista: View {
    let mensaje: Mensaje
    /// true si el mensaje lo envió el dueño de la conversación (burbuja a la derecha)
    let esPropio: Bool
    
    var body: some View {
        
        if mensaje.remitente == nil {
            // Aviso del sistema, centrado
            Text(mensaje.cuerpo)
                .font(.caption)
                .foregroundColor(.moradoAltar)
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(Capsule().fill(Color.moradoAltar.opacity(0.12)))
                .frame(maxWidth: .infinity)
        } else {
            HStack {
                if esPropio {
                    Spacer(minLength: 60)
                }
                
                Text(mensaje.cuerpo)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .foregroundColor(esPropio ? .nocheAltar : .papelPicado)
                    .background(esPropio ? Color.cempasuchil : Color.moradoAltar)
                    .clipShape(RoundedRectangle(cornerRadius: 18))
                
                if !esPropio {
                    Spacer(minLength: 60)
                }
            }
        }
    }
}

#Preview {
    VStack(spacing: 12) {
        MensajeVista(mensaje: ConversacionesFalsas[0].mensajes[0], esPropio: true)
        MensajeVista(mensaje: ConversacionesFalsas[0].mensajes[1], esPropio: false)
    }
    .padding()
}
