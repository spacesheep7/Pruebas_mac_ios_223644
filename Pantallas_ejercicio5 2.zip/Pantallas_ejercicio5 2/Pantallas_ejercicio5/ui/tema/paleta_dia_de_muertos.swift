//
//  paleta_dia_de_muertos.swift
//  Pantallas_ejercicio5
//
//  Colores alusivos al Día de Muertos.
//

import SwiftUI

extension Color {
    /// Naranja flor de cempasúchil
    static let cempasuchil = Color(red: 1.00, green: 0.55, blue: 0.10)
    /// Morado del altar
    static let moradoAltar = Color(red: 0.36, green: 0.13, blue: 0.47)
    /// Morado casi negro (noche de muertos)
    static let nocheAltar = Color(red: 0.17, green: 0.05, blue: 0.24)
    /// Crema tipo papel picado
    static let papelPicado = Color(red: 1.00, green: 0.95, blue: 0.84)
    /// Rosa mexicano
    static let rosaMexicano = Color(red: 0.85, green: 0.11, blue: 0.48)
}
