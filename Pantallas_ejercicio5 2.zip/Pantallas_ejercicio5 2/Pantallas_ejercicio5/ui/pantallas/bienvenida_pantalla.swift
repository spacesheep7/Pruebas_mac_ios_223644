//
//  bienvenida_pantalla.swift
//  Pantallas_ejercicio5
//
//  Pantalla de bienvenida de la app.
//

import SwiftUI

struct BienvenidaPantalla: View {
    /// Se ejecuta al tocar el botón para ir al altar
    var irAlAltar: () -> Void = {}
    
    var body: some View {
        ZStack {
            LinearGradient(colors: [.nocheAltar, .moradoAltar],
                           startPoint: .top,
                           endPoint: .bottom)
                .ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 20) {
                    Image(systemName: "fire.fill")
                        .font(.system(size: 54))
                        .foregroundColor(.cempasuchil)
                    
                    VStack(spacing: 4) {
                        Text("Bienvenido")
                            .font(.title3)
                            .foregroundColor(.papelPicado.opacity(0.8))
                        
                        Text("Juan Gabriel")
                            .font(.system(size: 40, weight: .bold, design: .serif))
                            .foregroundColor(.cempasuchil)
                        
                        Text("El Divo de Juárez · 1950 – 2016")
                            .font(.subheadline)
                            .foregroundColor(.papelPicado.opacity(0.8))
                    }
                    
                    Text("Esta es una app dedicada a Juan Gabriel. Cuenta con un altar en realidad aumentada con el que puedes interactuar.")
                        .multilineTextAlignment(.center)
                        .foregroundColor(.papelPicado)
                        .padding(.horizontal)
                    
                    VStack(alignment: .leading, spacing: 14) {
                        fila(icono: "arkit", texto: "Altar en realidad aumentada")
                        fila(icono: "hand.tap.fill", texto: "Interactúa con el altar")
                        fila(icono: "message.fill", texto: "Conversaciones con recuerdos y datos de su vida")
                    }
                    .padding(16)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.papelPicado.opacity(0.12)))
                    
                    Button(action: irAlAltar) {
                        Text("Ir al altar")
                            .font(.headline)
                            .foregroundColor(.nocheAltar)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(Capsule().fill(Color.cempasuchil))
                    }
                }
                .padding(24)
            }
        }
    }
    
    func fila(icono: String, texto: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icono)
                .foregroundColor(.cempasuchil)
                .frame(width: 28)
            Text(texto)
                .foregroundColor(.papelPicado)
        }
    }
}

#Preview {
    BienvenidaPantalla()
}
