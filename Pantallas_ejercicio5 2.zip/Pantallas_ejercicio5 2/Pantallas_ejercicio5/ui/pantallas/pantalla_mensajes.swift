//
//  pantalla_mensajes.swift
//  Pantallas_ejercicio5
//
//  Created by alumno on 11/9/26.
//


import SwiftUI

struct MensajesPantalla: View {
    let mensajes: [Mensaje]
    
    let yo: String
    let titulo: String
    
    var body: some View {
        ScrollView{
            LazyVStack(spacing:8){
                ForEach(mensajes){ mensaje in
                    MensajeVista(mensaje: mensaje,
                                 esPropio: mensaje.remitente == yo)
                    
                }
            }
            .padding()
            
        }
        .defaultScrollAnchor(.bottom)
        .background(Color.papelPicado)
        .navigationTitle(titulo)
        .navigationBarTitleDisplayMode(.inline)
    }
}

#Preview {
    NavigationStack {
        MensajesPantalla(
            mensajes: ConversacionesFalsas[0].mensajes,
            yo: ConversacionesFalsas[0].remitente,
            titulo: ConversacionesFalsas[0].receptor
        )
    }
}
