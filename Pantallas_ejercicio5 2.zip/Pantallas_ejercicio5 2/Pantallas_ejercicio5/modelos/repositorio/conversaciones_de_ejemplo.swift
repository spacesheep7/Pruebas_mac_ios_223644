//
//  mensajes_ejemplo.swift
//  Pantallas_ejercicio5
//
//  Created by alumno on 11/9/26.
//

let ConversacionesFalsas = [

    // 1) Lupita Ramírez ↔ Mariana — Discografía de Juan Gabriel
    Conversacion(
        remitente: "Lupita Ramírez",
        receptor: "Mariana",
        mensajes: [
            Mensaje(remitente: "Lupita Ramírez", receptor: "Mariana",
                    cuerpo: "Mari, ya armé mi lista de discos de Juan Gabriel para el altar. ¿Sabías que su primer álbum fue El Alma Joven, de 1971?"),
            Mensaje(remitente: "Mariana", receptor: "Lupita Ramírez",
                    cuerpo: "¡Ahí viene 'No tengo dinero'! Esa canción fue la que lo lanzó, ¿verdad?"),
            Mensaje(remitente: "Lupita Ramírez", receptor: "Mariana",
                    cuerpo: "Su primer gran éxito. Después llegaron discos como Con Tu Amor, Cosas de Enamorados y Pensamientos."),
            Mensaje(remitente: "Mariana", receptor: "Lupita Ramírez",
                    cuerpo: "Y no te olvides de Recuerdos, Vol. II, el de 'Querida' y 'Hasta que te conocí'. Dicen que es el disco más vendido en la historia de México."),
            Mensaje(remitente: "Lupita Ramírez", receptor: "Mariana",
                    cuerpo: "Más de ocho millones de copias desde 1984. Y el 9 de mayo de 1990 llenó el Palacio de Bellas Artes: fue el primero de música popular en presentarse ahí."),
            Mensaje(remitente: "Mariana", receptor: "Lupita Ramírez",
                    cuerpo: "Pues pon también el disco en vivo de Bellas Artes en el altar. Ese no puede faltar.")
        ]
    ),

    // 2) Don Chuy ↔ Toño — Datos de la vida de Juan Gabriel
    Conversacion(
        remitente: "Don Chuy",
        receptor: "Toño",
        mensajes: [
            Mensaje(remitente: "Don Chuy", receptor: "Toño",
                    cuerpo: "Toño, ¿sabías que Juan Gabriel se llamaba en realidad Alberto Aguilera Valadez?"),
            Mensaje(remitente: "Toño", receptor: "Don Chuy",
                    cuerpo: "Sí, nació en Parácuaro, Michoacán, el 7 de enero de 1950, ¿no?"),
            Mensaje(remitente: "Don Chuy", receptor: "Toño",
                    cuerpo: "Exacto, pero creció en Ciudad Juárez. Por eso le decían el Divo de Juárez."),
            Mensaje(remitente: "Toño", receptor: "Don Chuy",
                    cuerpo: "Y antes de la fama estuvo año y medio en la cárcel de Lecumberri, acusado de un robo, ¿cierto?"),
            Mensaje(remitente: "Don Chuy", receptor: "Toño",
                    cuerpo: "Ahí escribió canciones como 'No tengo dinero', y el director del penal lo ayudó a darse a conocer. En 1971 firmó con RCA Victor."),
            Mensaje(remitente: nil, receptor: nil,
                    cuerpo: "[Don Chuy se desconectó — fue a poner la ofrenda]")
        ]
    ),

    // 3) Abuela Chela ↔ Valeria — Día de Muertos y "Amor eterno"
    Conversacion(
        remitente: "Abuela Chela",
        receptor: "Valeria",
        mensajes: [
            Mensaje(remitente: "Abuela Chela", receptor: "Valeria",
                    cuerpo: "Mija, ya puse la foto de Juan Gabriel en la ofrenda, junto a la de tu abuelo y con su cempasúchil."),
            Mensaje(remitente: "Valeria", receptor: "Abuela Chela",
                    cuerpo: "¡Qué bonito, abue! ¿Por qué 'Amor eterno' se canta tanto en Día de Muertos?"),
            Mensaje(remitente: "Abuela Chela", receptor: "Valeria",
                    cuerpo: "La escribió cuando murió su mamá, y con el tiempo se volvió la canción para recordar a todos los que ya se fueron."),
            Mensaje(remitente: "Valeria", receptor: "Abuela Chela",
                    cuerpo: "Y él falleció el 28 de agosto de 2016 en Santa Mónica, California, ¿verdad?"),
            Mensaje(remitente: "Abuela Chela", receptor: "Valeria",
                    cuerpo: "Sí, hija. Dejó más de mil quinientas canciones, y en 2024 la Biblioteca del Congreso de Estados Unidos guardó 'Amor eterno' en su registro nacional de grabaciones."),
            Mensaje(remitente: "Valeria", receptor: "Abuela Chela",
                    cuerpo: "Entonces esta noche la ponemos para que no se sienta solo. Voy por el pan de muerto.")
        ]
    )
]
