//
//  pantalla_mensajes.swift
//  Pantallas_ejercicio5
//
//  Created by alumno on 11/9/26.
//


import SwiftUI

struct MensajesPantalla: View {
    let mensajes: [Mensaje]
    
    var body: some View {
        ScrollView{
            LazyVStack(spacing:12){
                ForEach(mensajes){ mensaje in
                    MensajeVista(mensaje: mensaje)
                    
                }
            }
            .padding()
            
        }
        .background(Color(red: 1.00, green: 0.95, blue: 0.84))
    }
}

#Preview {
    MensajesPantalla(
        mensajes: ConversacionesFalsas[0].mensajes
    )
}
