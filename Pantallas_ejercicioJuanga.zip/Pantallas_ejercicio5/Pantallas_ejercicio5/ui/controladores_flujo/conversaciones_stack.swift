//
//  conversaciones_stack.swift
//  Pantallas_ejercicio5
//
//  Created by alumno on 11/9/26.
//

import SwiftUI

struct ConversacionesControlVista:View {
    @Environment(MensajesControl.self) var mensajes_control
    
    var body: some View {
        NavigationStack
        {
            ForEach(mensajes_control.conversaciones){ conversacion in NavigationLink{
                MensajesPantalla(mensajes: conversacion.mensajes)
            }
                label: {VStack {
                    /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Content@*/Text("Placeholder")/*@END_MENU_TOKEN@*/
                }
                    ConversacionPrevista(conversacion: conversacion)
                }
                .foregroundColor(Color(red: 1.00, green: 0.95, blue: 0.84))
                .buttonStyle(.plain)
                .background(Color(red: 0.36, green: 0.13, blue: 0.47))
                .padding(12)
                
            }
        }
    }
}

#Preview {
    ConversacionesControlVista()
        .environment(MensajesControl())
}
