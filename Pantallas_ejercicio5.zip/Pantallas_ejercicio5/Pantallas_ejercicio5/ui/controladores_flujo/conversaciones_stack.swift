//
//  conversaciones_stack.swift
//  Pantallas_ejercicio5
//
//  Created by alumno on 11/9/26.
//

import SwiftUI

struct ConversacionesControlVista:View {
    @Environment(MensajesControl.self) var mensajes_control
    
    var body: some View {
        NavigationStack
        {
            ForEach(mensajes_control.conversaciones){ conversacion in NavigationLink{
                MensajesPantalla(mensajes: conversacion.mensajes)
            }
                label: {
                    ConversacionPrevista(conversacion: conversacion)
                }
                .buttonStyle(.plain)
                .background(Color.blue)
            }
        }
    }
}

#Preview {
    ConversacionesControlVista()
        .environment(MensajesControl())
}
